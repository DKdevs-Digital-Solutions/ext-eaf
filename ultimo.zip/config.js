// =============================================================
// CONFIGURAÇÕES DO CRM — edite aqui para mudar ambiente/credenciais
// =============================================================
const CRM_CONFIG = {
  // URL base da API do CRM (sem barra no final)
  baseUrl: 'https://crm-bot-stg.sigaantenado.com.br',

  // Endpoint para obter/renovar token
  authTokenUrl: 'https://crm-bot-stg.sigaantenado.com.br/crm/bot/api/v1/authorization/service/get-token',

  // Credenciais de serviço para autenticação
  authUsername: 'jefferson.soares@abjservicos.com.br',
  authPassword: 'Eaf@2026',

  // Header e esquema usados para enviar o token nas requisições
  tokenHeader: 'authorization',
  tokenScheme: 'bearer',

  // Modo de autenticação: 'token' = usa get-token com renovação automática
  authMode: 'token',

  // Caminho para atualizar dados do cliente no ticket
  ticketUpdatePath: '/crm/bot/api/v1/ticket/customer',

  // Label exibido acima do protocolo no painel
  crmLabel: 'Protocolo',

  // Mensagens exibidas quando a viabilidade do CEP retorna result=false
  // Chave = code retornado pela API (0 a 5)
  cepAvailabilityMessages: {
    0: 'CEP sem viabilidade de atendimento.',
    1: 'CEP fora da área de cobertura.',
    2: 'Cidade não está contemplada na fase atual do projeto.',
    3: 'Cidade não está contemplada na fase atual do projeto.',
    4: 'Periodo de atendimenot ainda não começou.',
    5: 'Periodo de agendamento encerrado.',
  },

};
