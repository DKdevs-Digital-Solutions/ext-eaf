// content.js — injeta o hook no Desk e faz ponte de mensagens
// Sem dependência de extension.services.dkdevs.com.br

let hookInjected = false;
let lastOpenRequestAt = 0;

// ─── Injeção do hook ─────────────────────────────────────────────────────────

function injectHook(callback) {
  if (hookInjected) return callback?.(true);
  try {
    chrome.runtime.sendMessage({ type: 'INJECT_HOOK' }, (response) => {
      if (chrome.runtime.lastError || !response?.ok) return callback?.(false);
      hookInjected = true;
      callback?.(true);
    });
  } catch { callback?.(false); }
}

// Settings mínimos para habilitar o sidebar sem depender de API externa
const HOOK_SETTINGS = {
  features: {
    deskSidebar: {
      enabled: true,
      useExtensionSidePanel: true,
    },
    messagePrefix: { enabled: false },
    ticketTagging:  { enabled: false },
  },
};

function sendEnableToHook() {
  window.postMessage({ __blipExt: true, type: 'ENABLE', enabled: true, settings: HOOK_SETTINGS }, '*');
}

function requestHookRefresh(forceReload = false) {
  window.postMessage({ __blipExt: true, type: 'REFRESH_PANEL_CONTEXT', forceReload, reason: 'sync' }, '*');
}

function bootstrap() {
  injectHook((ok) => {
    if (!ok) return;
    setTimeout(() => { sendEnableToHook(); requestHookRefresh(false); }, 250);
    setTimeout(() => { sendEnableToHook(); requestHookRefresh(true); }, 1200);
  });
}

bootstrap();

document.addEventListener('visibilitychange', () => {
  if (document.visibilityState === 'visible')
    injectHook((ok) => { if (ok) { sendEnableToHook(); requestHookRefresh(true); } });
});
window.addEventListener('focus', () => {
  injectHook((ok) => { if (ok) { sendEnableToHook(); requestHookRefresh(true); } });
});

let lastUrl = location.href;
setInterval(() => {
  if (location.href !== lastUrl) {
    lastUrl = location.href;
    injectHook((ok) => { if (ok) { sendEnableToHook(); requestHookRefresh(true); } });
  }
}, 1000);

// ─── Mensagens do background ──────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (!msg) return;
  if (msg.type === 'OPEN_ATTACHMENT_PREVIEW') {
    openAttachmentPreview(msg.items || [], msg.startIndex || 0);
    sendResponse?.({ ok: true });
    return;
  }

  if (msg.type === 'OPEN_CUSTOMER_DATA') {
    openCustomerDataOverlay(msg.rows || []);
    sendResponse?.({ ok: true });
    return;
  }
  if (msg.type === 'REFRESH_DESK_CONTEXT') {
    injectHook((ok) => {
      if (!ok) return sendResponse?.({ ok: false, error: 'INJECT_FAILED' });
      sendEnableToHook();
      requestHookRefresh(msg.forceReload !== false);
      sendResponse?.({ ok: true });
    });
    return true;
  }
});

// ─── Ponte window → chrome.runtime ───────────────────────────────────────────

window.addEventListener('message', (event) => {
  const data = event.data;
  if (data?.__dkSidePanel === true && data.type === 'SIDEPANEL_CONTEXT') {
    try { chrome.runtime.sendMessage({ type: 'DESK_CONTEXT_UPDATE', payload: data.payload || {} }); } catch {}
    return;
  }
  if (data?.__dkSidePanel === true && data.type === 'OPEN_SIDE_PANEL_REQUEST') {
    openSidePanelNow();
  }
});

// ─── Abertura do side panel ───────────────────────────────────────────────────

function openSidePanelNow() {
  const now = Date.now();
  if (now - lastOpenRequestAt < 500) return;
  lastOpenRequestAt = now;
  try {
    chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL' });
    setTimeout(() => chrome.runtime.sendMessage({ type: 'OPEN_SIDE_PANEL' }), 120);
  } catch {}
}

function isTicketClickEvent(event) {
  const path = typeof event.composedPath === 'function' ? event.composedPath() : [];
  const candidates = path.length ? path : [event.target];
  const selectors = [
    'article.ticket-list-item','article.chat-list-item',
    "article[id$='-chat-list-item']",'[data-ticket-id]',
    '[data-conversation-id]','[data-testid*="ticket" i]',
    '[data-testid*="conversation" i]','bds-card','li',
  ];
  for (const node of candidates) {
    if (!(node instanceof Element)) continue;
    for (const sel of selectors) {
      try { if (node.matches?.(sel) || node.closest?.(sel)) return true; } catch {}
    }
    const cls = String(node.className || '').toLowerCase();
    const tid = String(node.getAttribute?.('data-testid') || '').toLowerCase();
    if (cls.includes('ticket-list-item') || cls.includes('chat-list-item') || tid.includes('ticket') || tid.includes('conversation')) return true;
  }
  return false;
}

document.addEventListener('mousedown', (e) => { if (isTicketClickEvent(e)) openSidePanelNow(); }, true);
document.addEventListener('click', (e) => { if (isTicketClickEvent(e)) openSidePanelNow(); }, true);

// ─── Preview de anexos ────────────────────────────────────────────────────────

const PREVIEW_ROOT_ID = 'dk-attachment-preview-root';
let previewState = { items: [], index: 0, zoom: 1, drag: null };

function ensureAttachmentPreview() {
  let root = document.getElementById(PREVIEW_ROOT_ID);
  if (root) return root;
  root = document.createElement('div');
  root.id = PREVIEW_ROOT_ID;
  root.innerHTML = `<style>
    #${PREVIEW_ROOT_ID}{position:fixed;inset:0;z-index:2147483647;display:none}
    #${PREVIEW_ROOT_ID}.open{display:block}
    #${PREVIEW_ROOT_ID} .bk{position:absolute;inset:0;background:rgba(15,23,42,.76)}
    #${PREVIEW_ROOT_ID} .dg{position:absolute;inset:24px;background:#fff;border-radius:16px;box-shadow:0 20px 70px rgba(0,0,0,.35);overflow:hidden;display:flex;flex-direction:column}
    #${PREVIEW_ROOT_ID} .tb{display:flex;align-items:center;justify-content:flex-end;padding:10px;border-bottom:1px solid #e5e7eb}
    #${PREVIEW_ROOT_ID} .cl,.nv{border:1px solid #d1d5db;background:rgba(255,255,255,.96);color:#111827;border-radius:999px;cursor:pointer}
    #${PREVIEW_ROOT_ID} .cl{width:34px;height:34px;font-size:22px}
    #${PREVIEW_ROOT_ID} .st{position:relative;flex:1;min-height:0;overflow:auto;background:#f8fafc;display:flex;align-items:center;justify-content:center}
    #${PREVIEW_ROOT_ID} img{max-width:100%;max-height:100%;object-fit:contain;transform-origin:center;transition:transform .12s;cursor:zoom-in;user-select:none;-webkit-user-drag:none}
    #${PREVIEW_ROOT_ID} img.zoomed{cursor:grab}
    #${PREVIEW_ROOT_ID} img.dragging{cursor:grabbing}
    #${PREVIEW_ROOT_ID} .cp{padding:10px 16px 14px;text-align:center;font:13px Arial,sans-serif;color:#6b7280;border-top:1px solid #e5e7eb}
    #${PREVIEW_ROOT_ID} .nv{position:absolute;top:50%;transform:translateY(-50%);width:42px;height:42px;font-size:30px;z-index:2;display:flex;align-items:center;justify-content:center}
    #${PREVIEW_ROOT_ID} .pv{left:14px} #${PREVIEW_ROOT_ID} .nx{right:14px}
    #${PREVIEW_ROOT_ID} .hidden{display:none!important}
  </style>
  <div class="bk" data-close="1"></div>
  <div class="dg" role="dialog" aria-modal="true">
    <div class="tb"><button type="button" class="cl" aria-label="Fechar">×</button></div>
    <div class="st">
      <button type="button" class="nv pv" aria-label="Anterior">‹</button>
      <img alt="Anexo" />
      <button type="button" class="nv nx" aria-label="Próxima">›</button>
    </div>
    <div class="cp"></div>
  </div>`;
  document.documentElement.appendChild(root);

  root.addEventListener('click', (e) => {
    if (e.target.closest('[data-close="1"]') || e.target.closest('.cl')) closeAttachmentPreview();
    else if (e.target.closest('.pv')) { e.stopPropagation(); changePreview(-1); }
    else if (e.target.closest('.nx')) { e.stopPropagation(); changePreview(1); }
  });
  const img = root.querySelector('img'), stage = root.querySelector('.st');
  img.addEventListener('click', () => setPreviewZoom(previewState.zoom > 1 ? 1 : 2));
  stage.addEventListener('wheel', (e) => {
    if (!root.classList.contains('open')) return;
    e.preventDefault();
    setPreviewZoom(previewState.zoom + (e.deltaY < 0 ? 0.2 : -0.2));
  }, { passive: false });
  img.addEventListener('mousedown', (e) => {
    if (previewState.zoom <= 1) return;
    previewState.drag = { x: e.clientX, y: e.clientY, left: stage.scrollLeft, top: stage.scrollTop };
    img.classList.add('dragging'); e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!previewState.drag || previewState.zoom <= 1) return;
    stage.scrollLeft = previewState.drag.left - (e.clientX - previewState.drag.x);
    stage.scrollTop = previewState.drag.top - (e.clientY - previewState.drag.y);
  });
  window.addEventListener('mouseup', () => { previewState.drag = null; img.classList.remove('dragging'); });
  document.addEventListener('keydown', (e) => {
    if (!root.classList.contains('open')) return;
    if (e.key === 'Escape') closeAttachmentPreview();
    else if (e.key === 'ArrowLeft') changePreview(-1);
    else if (e.key === 'ArrowRight') changePreview(1);
    else if (e.key === '+' || e.key === '=') setPreviewZoom(previewState.zoom + 0.2);
    else if (e.key === '-') setPreviewZoom(previewState.zoom - 0.2);
  }, true);
  return root;
}

function setPreviewZoom(v) {
  const root = ensureAttachmentPreview(), img = root.querySelector('img');
  previewState.zoom = Math.min(4, Math.max(1, Number(v) || 1));
  img.style.transform = `scale(${previewState.zoom})`;
  img.classList.toggle('zoomed', previewState.zoom > 1);
  if (previewState.zoom <= 1) { const s = root.querySelector('.st'); s.scrollTop = 0; s.scrollLeft = 0; }
}
function renderPreview() {
  const root = ensureAttachmentPreview();
  const img = root.querySelector('img'), cap = root.querySelector('.cp');
  const pv = root.querySelector('.pv'), nx = root.querySelector('.nx');
  const item = previewState.items[previewState.index];
  if (!item) return;
  img.src = item.src; img.alt = item.name || 'Anexo';
  cap.textContent = `${item.name || 'Anexo'}${previewState.items.length > 1 ? ` — ${previewState.index + 1}/${previewState.items.length}` : ''}`;
  pv.classList.toggle('hidden', previewState.items.length < 2);
  nx.classList.toggle('hidden', previewState.items.length < 2);
  root.classList.add('open'); setPreviewZoom(1);
}
function openAttachmentPreview(items, startIndex) {
  previewState.items = Array.isArray(items) ? items.filter((x) => x?.src) : [];
  previewState.index = Math.max(0, Math.min(Number(startIndex) || 0, previewState.items.length - 1));
  if (!previewState.items.length) return;
  renderPreview();
}
function closeAttachmentPreview() {
  const root = document.getElementById(PREVIEW_ROOT_ID);
  if (!root) return;
  root.classList.remove('open');
  const img = root.querySelector('img');
  if (img) img.removeAttribute('src');
  previewState = { items: [], index: 0, zoom: 1, drag: null };
}
function changePreview(step) {
  if (previewState.items.length < 2) return;
  previewState.index = (previewState.index + step + previewState.items.length) % previewState.items.length;
  renderPreview();
}

// ─── Overlay de dados do cliente (injetado na página do Desk) ────────────────
const CDO_ROOT_ID = 'dk-customer-data-overlay';

function openCustomerDataOverlay(rows) {
  let root = document.getElementById(CDO_ROOT_ID);
  if (!root) {
    root = document.createElement('div');
    root.id = CDO_ROOT_ID;
    document.documentElement.appendChild(root);
  }

  root.innerHTML = `<style>
    #${CDO_ROOT_ID} { position:fixed; inset:0; z-index:2147483647; display:flex; align-items:center; justify-content:center; background:rgba(15,23,42,.62); }
    #${CDO_ROOT_ID} .cdo-dialog { background:#fff; border-radius:14px; box-shadow:0 16px 48px rgba(0,0,0,.28); width:360px; max-width:calc(100vw - 32px); max-height:80vh; display:flex; flex-direction:column; overflow:hidden; }
    #${CDO_ROOT_ID} .cdo-header { display:flex; align-items:center; justify-content:space-between; padding:14px 16px 12px; border-bottom:1px solid #e5e7eb; flex-shrink:0; }
    #${CDO_ROOT_ID} .cdo-title { font:700 15px/1 Arial,sans-serif; color:#121826; }
    #${CDO_ROOT_ID} .cdo-close { border:1px solid #d9e1ec; border-radius:999px; background:#fff; color:#121826; font-size:20px; width:28px; height:28px; cursor:pointer; display:flex; align-items:center; justify-content:center; }
    #${CDO_ROOT_ID} .cdo-body { overflow-y:auto; flex:1; padding:4px 0 8px; }
    #${CDO_ROOT_ID} .cdo-row { display:flex; justify-content:space-between; align-items:baseline; gap:12px; padding:9px 16px; border-bottom:1px solid #f1f3f5; font-family:Arial,sans-serif; }
    #${CDO_ROOT_ID} .cdo-row:last-child { border-bottom:0; }
    #${CDO_ROOT_ID} .cdo-label { font-size:11px; font-weight:700; color:#667085; flex-shrink:0; }
    #${CDO_ROOT_ID} .cdo-value { font-size:13px; font-weight:500; color:#121826; text-align:right; word-break:break-word; }
  </style>
  <div class="cdo-dialog">
    <div class="cdo-header">
      <span class="cdo-title">Dados do cliente</span>
      <button class="cdo-close" id="cdoClose">×</button>
    </div>
    <div class="cdo-body">
      ${rows.map(([label, value]) =>
        `<div class="cdo-row"><span class="cdo-label">${label}</span><span class="cdo-value">${value || '—'}</span></div>`
      ).join('')}
    </div>
  </div>`;

  root.style.display = 'flex';

  root.querySelector('#cdoClose')?.addEventListener('click', closeCustomerDataOverlay);
  root.addEventListener('click', (e) => { if (e.target === root) closeCustomerDataOverlay(); });

  document.addEventListener('keydown', function escListener(e) {
    if (e.key === 'Escape') { closeCustomerDataOverlay(); document.removeEventListener('keydown', escListener); }
  });
}

function closeCustomerDataOverlay() {
  const root = document.getElementById(CDO_ROOT_ID);
  if (root) root.style.display = 'none';
}
