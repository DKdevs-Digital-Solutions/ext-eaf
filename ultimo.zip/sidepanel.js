// sidepanel.js
// Lê configurações de CRM_CONFIG (definido em config.js, carregado antes deste script)

// ─── Estado global ────────────────────────────────────────────────────────────

let currentTabId = null;

let currentState = null;
let activeTab = 'validador';
const DESK_URL_RE = /^https:\/\/[^/]+\.desk\.blip\.ai\//i;

// Validador — URL fixa, sempre presente
const VALIDATOR_BASE_URL = 'https://sigaantenado.datasintese.com/crm_eaf/validacao_beneficiario_atualiza_tentativas_processa.php';
const VALIDATOR_TOKEN    = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiMjAyNCIsImlhdCI6MTcwMTg5MzIzM30.A-y9Zr4VpWfhQAEwmaKo4u6Lbu7-Sq5H9X_hRdAdJLY';
const VALIDATOR_ID_CRM   = '2024171953';
const VALIDATOR_GRUPO    = '9';

const R2_BASE_URL = 'https://pub-c54ecb6f6021463e95790b49774c4e8c.r2.dev';
const R2_ATTACHMENTS = [
  { name: 'frente.jpg', label: 'Frente' },
  { name: 'self.png',   label: 'Self'   },
  { name: 'tv.jpg',     label: 'TV'     },
  { name: 'verso.png',  label: 'Verso'  },
];

// ─── Configuração da API (lida de config.js) ──────────────────────────────────

function getApiConfig() {
  // CRM_CONFIG é definido em config.js, que deve ser carregado antes deste script
  const cfg = (typeof CRM_CONFIG !== 'undefined' ? CRM_CONFIG : {});
  return {
    baseUrl:      String(cfg.baseUrl      || 'https://crm-bot-stg.sigaantenado.com.br').trim().replace(/\/+$/, ''),
    authTokenUrl: String(cfg.authTokenUrl || 'https://crm-bot-stg.sigaantenado.com.br/crm/bot/api/v1/authorization/service/get-token').trim(),
    authUsername: String(cfg.authUsername || '').trim(),
    authPassword: String(cfg.authPassword || '').trim(),
    tokenHeader:  String(cfg.tokenHeader  || 'authorization').trim().toLowerCase(),
    tokenScheme:  String(cfg.tokenScheme  || 'bearer').trim().toLowerCase(),
    authMode:     String(cfg.authMode     || 'token').trim().toLowerCase(),
    ticketUpdatePath: String(cfg.ticketUpdatePath || '/crm/bot/api/v1/ticket/customer').trim(),
    crmLabel:     String(cfg.crmLabel     || 'Protocolo').trim(),
    // validatorUrl removido — URL do validador é sempre montada dinamicamente (buildValidatorUrl)
  };
}

// ─── Cache & tokens ───────────────────────────────────────────────────────────

const attachmentCache   = new Map();
const ticketCache       = new Map();
const availabilityCache = new Map();
let attachmentsRequestToken   = 0;
let ticketRequestToken        = 0;
let availabilitiesRequestToken= 0;

// Token em memória e storage
const AUTH_STORAGE_KEY    = 'crmAuthTokens';
const AUTH_EXPIRY_SKEW_MS = 60 * 1000; // renova 60s antes de expirar
let authTokenMemory = null;   // { token, expiresAt, updatedAt }
let authTokenInflight = null; // Promise em andamento (evita corrida)

// Modal de imagem
let modalGalleryItems = [];
let modalGalleryIndex = -1;
let modalZoom = 1;
let modalDragState = null;

// ─── Helpers de storage ───────────────────────────────────────────────────────

async function storageGet(key) {
  return new Promise((resolve) => {
    try { chrome.storage.local.get([key], (r) => resolve(r?.[key] ?? null)); }
    catch { resolve(null); }
  });
}
async function storageSet(key, value) {
  return new Promise((resolve) => {
    try { chrome.storage.local.set({ [key]: value }, () => resolve(true)); }
    catch { resolve(false); }
  });
}

// ─── Token: obtenção e renovação automática ───────────────────────────────────

function decodeJwtExp(token) {
  try {
    const parts = String(token || '').split('.');
    if (parts.length < 2) return null;
    const payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
    const expMs = Number(payload?.exp || 0) * 1000;
    return Number.isFinite(expMs) && expMs > 0 ? expMs : null;
  } catch { return null; }
}

function isTokenValid(entry) {
  if (!entry?.token) return false;
  const exp = Number(entry.expiresAt || 0);
  if (!exp) return true; // sem exp conhecido → assume válido
  return Date.now() + AUTH_EXPIRY_SKEW_MS < exp;
}

function computeExpiresAt(json, token) {
  const now = Date.now();
  const rawExpiresAt = json?.expiresAt || json?.expireAt || json?.data?.expiresAt;
  if (rawExpiresAt) { const ms = Date.parse(rawExpiresAt); if (Number.isFinite(ms)) return ms; }
  const expiresIn = Number(json?.expiresIn || json?.expires_in || json?.data?.expiresIn || json?.data?.expires_in || 0);
  if (expiresIn > 0) return now + expiresIn * 1000;
  const jwtExp = decodeJwtExp(token);
  if (jwtExp) return jwtExp;
  return now + 50 * 60 * 1000; // fallback: 50 min
}

function pickTokenFromResponse(json) {
  if (!json) return '';
  return json.token || json.accessToken || json.access_token ||
         json?.data?.token || json?.data?.accessToken || json?.data?.access_token || '';
}

async function fetchNewToken() {
  const cfg = getApiConfig();
  if (!cfg.authTokenUrl || !cfg.authUsername || !cfg.authPassword) {
    throw new Error('Credenciais de serviço não configuradas em config.js (authUsername / authPassword).');
  }
  const res = await fetch(cfg.authTokenUrl, {
    method: 'POST',
    headers: { 'content-type': 'application/json', 'accept': 'application/json' },
    body: JSON.stringify({ username: cfg.authUsername, password: cfg.authPassword }),
    cache: 'no-store',
  });
  let json = null;
  try { json = await res.json(); } catch {}
  if (!res.ok) {
    const msg = json?.message || json?.error || `HTTP ${res.status}`;
    throw new Error(`Falha ao obter token (${res.status}): ${msg}`);
  }
  const token = String(pickTokenFromResponse(json) || '').trim();
  if (!token) throw new Error('Resposta do get-token não contém campo token/accessToken.');
  return { token, expiresAt: computeExpiresAt(json, token), updatedAt: Date.now() };
}

async function ensureAuthToken({ force = false } = {}) {
  // 1. memória
  if (!force && isTokenValid(authTokenMemory)) return authTokenMemory;

  // 2. storage
  if (!force) {
    const all = (await storageGet(AUTH_STORAGE_KEY)) || {};
    const stored = all?.['default'] || null;
    if (isTokenValid(stored)) {
      authTokenMemory = stored;
      return authTokenMemory;
    }
  }

  // 3. busca novo — evita corrida com inflight
  if (authTokenInflight) return authTokenInflight;
  authTokenInflight = (async () => {
    try {
      const entry = await fetchNewToken();
      authTokenMemory = entry;
      const all = (await storageGet(AUTH_STORAGE_KEY)) || {};
      all['default'] = entry;
      await storageSet(AUTH_STORAGE_KEY, all);
      return entry;
    } finally {
      authTokenInflight = null;
    }
  })();
  return authTokenInflight;
}

// ─── Requisição autenticada com retry 401 ─────────────────────────────────────

async function apiRequest(path, options = {}) {
  const cfg = getApiConfig();
  const url = path.startsWith('http') ? path : `${cfg.baseUrl}${path}`;
  const headers = new Headers(options.headers || {});
  if (!headers.has('accept')) headers.set('accept', 'application/json');

  async function applyToken(force = false) {
    if (cfg.authMode !== 'token') return;
    const entry = await ensureAuthToken({ force });
    if (entry?.token) {
      const scheme = cfg.tokenScheme === 'bearer' ? `Bearer ${entry.token}` : entry.token;
      headers.set(cfg.tokenHeader, scheme);
    }
  }

  await applyToken(false);

  let response = await fetch(url, { ...options, headers });

  // Retry automático em 401: renova token e tenta uma vez mais
  if (response.status === 401 && cfg.authMode === 'token') {
    try {
      await applyToken(true); // force=true: ignora cache, busca novo
      response = await fetch(url, { ...options, headers });
    } catch {
      // se renovação falhar, mantém a resposta 401 original
    }
  }

  const contentType = response.headers.get('content-type') || '';
  let body = null;
  try { body = contentType.includes('application/json') ? await response.json() : await response.text(); } catch {}

  if (!response.ok) {
    const base = typeof body === 'string' && body ? body : (body?.message || body?.error || `HTTP ${response.status}`);
    const msg = response.status === 401
      ? `Não autorizado (401). Verifique authUsername/authPassword em config.js. (${base})`
      : base;
    throw new Error(msg);
  }
  return body;
}

// ─── Utilitários ──────────────────────────────────────────────────────────────

function qs(sel) { return document.querySelector(sel); }
function escapeHtml(v) {
  return String(v ?? '')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}
function normalizeDigits(v)    { return String(v || '').replace(/\D+/g, ''); }
function normalizeProtocol(v)  { return String(v || '').trim(); }
function normalizePostalCode(v){ return normalizeDigits(v).slice(0, 8); }
function isBlank(v)            { return v == null || String(v).trim() === ''; }
function coalesce(...vals) {
  for (const v of vals) { if (!isBlank(v)) return String(v).trim(); }
  return '';
}
function deepFind(obj, keys) {
  if (!obj || typeof obj !== 'object') return '';
  const queue = [obj], seen = new Set(), lowered = keys.map((k) => String(k).toLowerCase());
  while (queue.length) {
    const cur = queue.shift();
    if (!cur || typeof cur !== 'object' || seen.has(cur)) continue;
    seen.add(cur);
    for (const [k, v] of Object.entries(cur)) {
      const lk = String(k).toLowerCase();
      if (lowered.includes(lk) && v != null && (typeof v !== 'object' || Array.isArray(v))) return v;
      if (v && typeof v === 'object') queue.push(v);
    }
  }
  return '';
}
function formatBytes(bytes) {
  const v = Number(bytes || 0);
  if (!v) return '';
  if (v < 1024) return `${v} B`;
  if (v < 1024*1024) return `${(v/1024).toFixed(1).replace('.0','')} KB`;
  return `${(v/1024/1024).toFixed(1).replace('.0','')} MB`;
}
function isImageAttachment(name, type = '') {
  return /^image\//i.test(type) || /\.(png|jpe?g|webp|gif|bmp)$/i.test(String(name || ''));
}
function formatScheduleDate(value) {
  if (!value) return '—';
  const d = new Date(`${value}T00:00:00`);
  return Number.isNaN(d.getTime()) ? value : d.toLocaleDateString('pt-BR');
}

// ─── Normalização de dados do ticket ─────────────────────────────────────────

function normalizeTicketPayload(raw, fallback = {}) {
  // Estrutura real da API: { customer: { address: {...}, contacts: [...], cpf, name, ... }, services: [...], uuid }
  const cn  = raw?.customer && typeof raw.customer === 'object' ? raw.customer : raw;
  const addr = cn?.address && typeof cn.address === 'object' ? cn.address : {};
  const cadu = cn?.cadUnico && typeof cn.cadUnico === 'object' ? cn.cadUnico : {};

  // Telefone: contacts[] — MOBILE é o principal, phone2 é o secundário
  const contacts = Array.isArray(cn?.contacts) ? cn.contacts : [];
  const mobileContact = contacts.find(c => c?.type === 'MOBILE' || c?.type === 'mobile') || contacts.find(c => c?.value);
  const phone2Contact = contacts.find(c => c?.type === 'phone2' || c?.type === 'PHONE2');
  const phone1 = coalesce(mobileContact?.value, fallback?.telefone, fallback?.phone);
  const phoneOutro2 = coalesce(phone2Contact?.value, fallback?.phoneOutro2);

  // CEP: customer.address.postalCode (estrutura real da API)
  const postalCode = normalizePostalCode(
    coalesce(addr?.postalCode, cadu?.postalCode, cn?.postalCode, cn?.cep, fallback?.cep)
  );

  // Endereço: customer.address.*
  const logradouro  = coalesce(addr?.streetName,    cn?.logradouro,   fallback?.logradouro);
  const number      = coalesce(addr?.number,         cn?.number,       cn?.numero,   fallback?.numero);
  const complemento = coalesce(addr?.complement,     cn?.complemento,  fallback?.complemento);
  const bairro      = coalesce(addr?.neighborhood,   cn?.bairro,       fallback?.bairro);
  const cidade      = coalesce(addr?.city,           cn?.city,         cn?.cidade,   fallback?.cidade);
  const uf          = coalesce(addr?.state,          cn?.uf,           cn?.state,    fallback?.uf);
  const referencia  = coalesce(addr?.reference,      cn?.reference,    cn?.pontoReferencia, fallback?.pontoReferencia);

  // ibgeCode: customer.cadUnico.ibgeCode
  const ibgeCode = coalesce(cadu?.ibgeCode, cn?.ibgeCode, fallback?.ibgeCode);

  // Protocolo: pega o último service (mais recente) pois a API retorna em ordem cronológica
  const services = Array.isArray(raw?.services) ? raw.services : [];
  const lastService = services.length ? services[services.length - 1] : null;
  const protocolNumber = coalesce(
    lastService?.protocol?.number,
    services[0]?.protocol?.number,
    raw?.protocolNumber,
    raw?.protocol,
    fallback?.protocolNumber
  );

  // uuid do ticket
  const uuid = coalesce(raw?.uuid, cn?.uuid, cn?.id);

  const customer = {
    nome:        coalesce(cn?.name, cn?.nome, fallback?.nome, fallback?.name),
    name:        coalesce(cn?.name, cn?.nome, fallback?.name, fallback?.nome),
    cpf:         coalesce(cn?.cpf,  cn?.document, fallback?.cpf, fallback?.document),
    document:    coalesce(cn?.cpf,  cn?.document, fallback?.document, fallback?.cpf),
    telefone:    phone1,
    phone:       phone1,
    phoneOutro2,
    email:       coalesce(cn?.email, fallback?.email),
    cidade,
    city:        cidade,
    uf,
    estado:      uf,
    cep:         postalCode,
    bairro,
    logradouro,
    endereco:    logradouro,
    complemento,
    number,
    numero:      number,
    pontoReferencia: referencia,
    uuid,
    ibgeCode,
  };
  return { raw, customer, customerUuid: uuid, protocolNumber, ibgeCode };
}

// Mescla dados: API de ticket tem prioridade sobre DOM (profileInfo)
// Protocolo vem SEMPRE do profileInfo (state.protocol / state.ticketDisplay)
function getEffectiveCustomer(state) {
  const base    = state?.customer || {};          // dados do DOM (profileInfo)
  const fromApi = state?.ticketApi?.customer || {}; // dados da API de ticket

  return {
    ...base,
    ...fromApi,
    nome:     coalesce(fromApi.nome, fromApi.name, base.nome, base.name),
    name:     coalesce(fromApi.name, fromApi.nome, base.name, base.nome),
    cpf:      coalesce(fromApi.cpf, fromApi.document, base.cpf, base.document),
    document: coalesce(fromApi.document, fromApi.cpf, base.document, base.cpf),
    telefone: coalesce(fromApi.telefone, fromApi.phone, base.telefone, base.phone),
    phone:    coalesce(fromApi.phone, fromApi.telefone, base.phone, base.telefone),
    phoneOutro2: coalesce(fromApi.phoneOutro2, base.phoneOutro2),
    email:    coalesce(fromApi.email, base.email),
    cidade:   coalesce(fromApi.cidade, fromApi.city, base.cidade, base.city),
    city:     coalesce(fromApi.city, fromApi.cidade, base.city, base.cidade),
    uf:       coalesce(fromApi.uf, fromApi.estado, base.uf, base.estado),
    estado:   coalesce(fromApi.estado, fromApi.uf, base.estado, base.uf),
    cep:      coalesce(fromApi.cep, base.cep),
    bairro:   coalesce(fromApi.bairro, base.bairro),
    logradouro: coalesce(fromApi.logradouro, base.logradouro),
    endereco:   coalesce(fromApi.endereco, base.endereco, fromApi.logradouro, base.logradouro),
    complemento: coalesce(fromApi.complemento, base.complemento),
    number:   coalesce(fromApi.number, fromApi.numero, base.number, base.numero),
    numero:   coalesce(fromApi.numero, fromApi.number, base.numero, base.number),
    pontoReferencia: coalesce(fromApi.pontoReferencia, base.pontoReferencia),
    uuid:     coalesce(fromApi.uuid, base.uuid, state?.ticketApi?.customerUuid),
    // Protocolo: SEMPRE do profileInfo (DOM) — nunca da API de ticket
    protocolNumber: coalesce(state?.protocol, state?.ticketDisplay, state?.ticketApi?.protocolNumber),
    ibgeCode: coalesce(fromApi.ibgeCode, state?.ticketApi?.ibgeCode, base.ibgeCode),
  };
}

function getCurrentDocument(state) {
  const c = getEffectiveCustomer(state || currentState || {});
  return normalizeDigits(c.document || c.cpf);
}

// ─── Carregamento de dados do ticket ─────────────────────────────────────────

async function ensureTicketDataLoaded(state, { force = false } = {}) {
  const doc = getCurrentDocument(state);
  if (!doc) return;
  // Use ticketId + document as cache key so different tickets with same CPF don't collide
  const cacheKey = `${state?.ticketId || ''}_${doc}`;
  if (!force && state?.ticketApi?.cacheKey === cacheKey) return;

  // cache local por ticketId+document
  if (!force && ticketCache.has(cacheKey)) {
    if (currentState) {
      currentState.ticketApi = { ...ticketCache.get(cacheKey), cacheKey };
      renderCustomer(currentState);
      renderSchedule(currentState);
    }
    return;
  }

  const token = ++ticketRequestToken;
  try {
    const raw = await apiRequest(`/crm/bot/api/v1/ticket?document=${encodeURIComponent(doc)}&document-type=CPF`, { method: 'GET' });
    if (token !== ticketRequestToken) return;
    const normalized = normalizeTicketPayload(raw, state?.customer || {});
    const payload = { ...normalized, cacheKey };
    ticketCache.set(cacheKey, payload);
    if (!currentState) return;
    currentState.ticketApi = payload;
    // NÃO sobrescreve protocol — preserva o que veio do profileInfo
    renderCustomer(currentState);
    renderSchedule(currentState);
  } catch (err) {
    if (token !== ticketRequestToken) return;
    if (currentState) {
      currentState.ticketApiError = err?.message || 'Falha ao consultar a API de ticket.';
      if (activeTab === 'cliente')     renderCustomer(currentState);
      if (activeTab === 'agendamento') renderSchedule(currentState);
    }
  }
}

// ─── Agendamento ──────────────────────────────────────────────────────────────

function scheduleRequestKey(state) {
  const c = getEffectiveCustomer(state);
  const postalCode = normalizePostalCode(c.cep);
  const protocol   = normalizeProtocol(state?.protocol || state?.ticketDisplay || state?.ticketApi?.protocolNumber || '');
  return postalCode && protocol ? `${postalCode}:${protocol}` : '';
}

async function ensureAvailabilitiesLoaded(state, { force = false } = {}) {
  const c = getEffectiveCustomer(state);
  const postalCode = normalizePostalCode(c.cep);
  // Protocolo: DOM primeiro
  const protocol = normalizeProtocol(state?.protocol || state?.ticketDisplay || state?.ticketApi?.protocolNumber || '');

  if (!postalCode || !protocol) {
    if (currentState) {
      currentState.scheduleLoading = false;
      currentState.scheduleError = !protocol
        ? 'Protocolo não disponível. Aguarde o carregamento dos dados do ticket.'
        : 'CEP não disponível. Verifique os dados do cliente.';
      renderSchedule(currentState);
    }
    return;
  }

  const key = `${postalCode}:${protocol}`;
  if (!force && state?.scheduleOptionsLoaded) return;

  if (!force && availabilityCache.has(key)) {
    currentState.scheduleOptions = availabilityCache.get(key);
    currentState.scheduleOptionsLoaded = true;
    renderSchedule(currentState);
    return;
  }

  const reqToken = ++availabilitiesRequestToken;
  currentState.scheduleLoading = true;
  renderSchedule(currentState);

  try {
    const raw = await apiRequest(`/crm/bot/api/v1/capacity/availabilities?postal-code=${encodeURIComponent(postalCode)}&protocol=${encodeURIComponent(protocol)}`, { method: 'GET' });
    if (reqToken !== availabilitiesRequestToken) return;
    const schedules = Array.isArray(raw?.data?.schedules) ? raw.data.schedules
                    : Array.isArray(raw?.schedules)        ? raw.schedules
                    : [];
    availabilityCache.set(key, schedules);
    currentState.scheduleOptions = schedules;
    currentState.scheduleOptionsLoaded = true;
    currentState.scheduleLoading = false;
    currentState.scheduleError = '';
    if (!currentState.selectedScheduleDate && schedules[0]?.date)
      currentState.selectedScheduleDate = schedules[0].date;
    renderSchedule(currentState);
  } catch (err) {
    if (reqToken !== availabilitiesRequestToken) return;
    currentState.scheduleLoading = false;
    currentState.scheduleError = err?.message || 'Falha ao carregar datas disponíveis.';
    renderSchedule(currentState);
  }
}

async function submitSelectedSchedule(cancel = false) {
  const c = getEffectiveCustomer(currentState);
  // Protocolo: DOM primeiro
  const protocol = normalizeProtocol(currentState?.protocol || currentState?.ticketDisplay || currentState?.ticketApi?.protocolNumber || c.protocolNumber || '');
  const options  = Array.isArray(currentState?.scheduleOptions) ? currentState.scheduleOptions : [];
  const selectedDate = currentState?.selectedScheduleDate || options[0]?.date || '';
  const selected = options.find((o) => o.date === selectedDate) || options[0];

  if (!protocol || !options.length) throw new Error('Nenhuma data disponível para enviar.');
  if (!cancel && !selected?.date)   throw new Error('Selecione uma data disponível.');

  const payload = {
    ibgeCode:       selected?.ibgeCode || options[0]?.ibgeCode || c.ibgeCode || currentState?.ticketApi?.ibgeCode || '',
    priority:       1,
    protocolNumber: protocol,
    reasonPriority: cancel ? 'Cancelamento de agendamento' : 'Agendamento de instalação',
    schedules:      options.map((o) => ({ chose: cancel ? false : o.date === selectedDate, date: o.date, installer: o.installer })),
    tabulation:     cancel ? 'Cancelamento' : 'Agendamento',
  };

  await apiRequest('/crm/bot/api/v1/service-order/schedule', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  const msg = cancel
    ? 'Agendamento cancelado com sucesso.'
    : `Agendamento realizado para ${formatScheduleDate(selectedDate)}.`;

  // Reseta para tela inicial do agendamento
  currentState.scheduleOptionsLoaded = false;
  currentState.scheduleOptions = [];
  currentState.selectedScheduleDate = '';
  currentState.scheduleLoading = false;
  currentState.scheduleError = '';
  currentState.scheduleSuccess = '';
  if (!cancel) {
    currentState.schedule = { data: selectedDate, date: selectedDate, owner: selected?.installer || '' };
  }
  renderSchedule(currentState);

  // Toast igual ao do protocolo
  showCustomerToast(msg);
}

// ─── Anexos R2 ────────────────────────────────────────────────────────────────

const EAF_BASE_URL = 'https://services-eaf.dkdevs.com.br';

async function fetchEafAttachments(protocol, ticketId) {
  const p = normalizeProtocol(protocol);
  if (!p) return [];
  const cacheKey = `${p}_${ticketId || ''}`;
  if (attachmentCache.has(cacheKey)) return attachmentCache.get(cacheKey);
  const params = new URLSearchParams({ protocol: p });
  if (ticketId) params.set('ticketId', ticketId);
  const r = await fetch(`${EAF_BASE_URL}/files?${params}`, { method: 'GET', headers: { accept: 'application/json' } });
  if (!r.ok) throw new Error(`EAF /files retornou ${r.status}`);
  const data = await r.json();
  // Normaliza: API pode retornar array ou { files: [...] }
  // Resposta: { prefix, items: [...] }
  const raw = Array.isArray(data) ? data : (Array.isArray(data?.items) ? data.items : []);
  const found = raw.map((item) => ({
    attachmentId: item.attachmentId || '',
    nome:         item.fileName || item.key?.split('/').pop() || 'Arquivo',
    titulo:       item.name || item.fileName || '',
    tipo:         item.fileName?.match(/\.([^.]+)$/) ? `image/${item.fileName.split('.').pop().toLowerCase()}` : '',
    tamanho:      Number(item.size || 0),
    url:          item.publicUrl || '',
    key:          item.key || '',
    protocol:     p,
    ticketId:     ticketId || '',
  }));
  attachmentCache.set(cacheKey, found);
  return found;
}

async function ensureAttachmentsLoaded(state, { force = false } = {}) {
  const protocol = normalizeProtocol(state?.protocol || state?.ticketDisplay || state?.ticketApi?.protocolNumber || '');
  const ticketId = state?.ticketId || '';
  const listEl = qs('#attachmentsList');
  if (!listEl) return;
  if (!protocol) { listEl.innerHTML = '<div class="empty">Nenhum protocolo disponível para buscar anexos.</div>'; return; }
  if (!force && Array.isArray(state?.attachments) && state.attachments.length) { renderAttachments(state); return; }
  const token = ++attachmentsRequestToken;
  listEl.innerHTML = '<div class="empty">Buscando anexos...</div>';
  try {
    const attachments = await fetchEafAttachments(protocol, ticketId);
    if (token !== attachmentsRequestToken) return;
    if (currentState) currentState.attachments = attachments;
    renderAttachments({ ...(currentState || state || {}), attachments });
  } catch (err) {
    if (token !== attachmentsRequestToken) return;
    listEl.innerHTML = `<div class="empty">Não foi possível carregar os anexos: ${escapeHtml(err?.message || '')}.</div>`;
  }
}

// ─── Salvar dados do cliente ──────────────────────────────────────────────────

// ─── Datasintese: token em memória ───────────────────────────────────────────
// ─── Viabilidade de CEP via CRM ──────────────────────────────────────────────
// Mensagens por code quando result=false
// Mensagens lidas de CRM_CONFIG.cepAvailabilityMessages (config.js)
function getCepAvailabilityMessage(code) {
  const msgs = (typeof CRM_CONFIG !== 'undefined' ? CRM_CONFIG.cepAvailabilityMessages : null) || {};
  return msgs[code] ?? `Sem viabilidade (código ${code ?? '?'}).`;
}

async function checkCepAvailability(cep) {
  const n = normalizePostalCode(cep);
  if (n.length !== 8) throw new Error('CEP inválido. Informe 8 dígitos.');
  const protocol = normalizeProtocol(
    currentState?.protocol || currentState?.ticketDisplay || currentState?.ticketApi?.protocolNumber || ''
  );
  if (!protocol) throw new Error('Protocolo não disponível para consulta de viabilidade.');
  const raw = await apiRequest(
    `/crm/bot/api/v1/city-availability?extra-phase=true&postalCode=${encodeURIComponent(n)}&protocol=${encodeURIComponent(protocol)}`,
    { method: 'GET' }
  );
  return raw; // { result, code, errors, address: { postalCode, publicPlace, neighborhood, locality, state, ibge } }
}

async function syncCustomerToTicket(patch, { cepWasChanged = false } = {}) {
  const cfg = getApiConfig();
  const c   = getEffectiveCustomer(currentState);
  const uuid = currentState?.ticketApi?.raw?.uuid || currentState?.ticketApi?.customerUuid || c.uuid || '';
  if (!uuid) throw new Error('uuid do ticket não disponível para atualizar.');

  // Monta contacts: preserva os existentes e atualiza valores editados
  const existingContacts = Array.isArray(currentState?.ticketApi?.raw?.customer?.contacts)
    ? currentState.ticketApi.raw.customer.contacts : [];

  // Atualiza telefone2 se alterado
  const contacts = existingContacts.length ? existingContacts.map(ct => ({ ...ct })) : [];
  if (patch.phoneOutro2 !== undefined) {
    const idx = contacts.findIndex(ct => ct.type === 'phone2' || ct.type === 'PHONE2');
    if (idx >= 0) contacts[idx].value = patch.phoneOutro2;
    else if (patch.phoneOutro2) contacts.push({ type: 'phone2', value: patch.phoneOutro2, acceptContact: true, whatsapp: false });
  }

  // Monta payload na estrutura esperada pela API
  const payload = {
    uuid,
    customer: {
      email: patch.email !== undefined ? (patch.email || '') : (c.email || ''),
      contacts,
      address: {
        postalCode:   patch.cep          ?? c.cep          ?? '',
        streetName:   patch.logradouro   ?? c.logradouro   ?? c.endereco ?? '',
        neighborhood: patch.bairro       ?? c.bairro       ?? '',
        number:       patch.numero       ?? patch.number   ?? c.numero ?? c.number ?? '',
        complement:   patch.complemento  ?? c.complemento  ?? '',
        reference:    patch.pontoReferencia ?? c.pontoReferencia ?? '',
        city:         patch.cidade       ?? c.cidade       ?? c.city   ?? '',
        state:        patch.uf           ?? c.uf           ?? c.estado ?? '',
        latlong:      '',
      },
    },
  };

  const fullUrl = `${cfg.baseUrl}${cfg.ticketUpdatePath}/${encodeURIComponent(uuid)}`;
  const bodyStr = JSON.stringify(payload, null, 2);

  // LOG VISUAL — remove após diagnóstico
  const logEl = qs('#customerAddressFeedback');
  if (logEl) logEl.textContent = `PUT → ${fullUrl}

PAYLOAD:
${bodyStr}`;

  const result = await apiRequest(`${cfg.ticketUpdatePath}/${encodeURIComponent(uuid)}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: bodyStr,
  });
  return result;
}



async function updateCustomerAddress(formData) {
  const c = getEffectiveCustomer(currentState);
  const nextTelefone2  = String(formData.get('telefone2')       || '').trim();
  const nextEmail      = String(formData.get('email')           || '').trim();
  const nextCepRaw     = String(formData.get('cep')             || '').trim();
  const nextLogradouro = String(formData.get('logradouro')      || '').trim();
  const nextBairro     = String(formData.get('bairro')          || '').trim();
  const nextNumero     = String(formData.get('numero')          || '').trim();
  const nextComplemento= String(formData.get('complemento')     || '').trim();
  const nextReferencia = String(formData.get('pontoReferencia') || '').trim();

  if (nextEmail && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(nextEmail))
    throw new Error('E-mail inválido.');

  const prevCep = normalizePostalCode(c.cep);
  const nextCep = nextCepRaw ? normalizePostalCode(nextCepRaw) : prevCep;

  // Salvar nunca verifica CEP — isso é feito pelo botão "Consultar CEP"
  const patch = {
    phoneOutro2:     nextTelefone2   || c.phoneOutro2 || '',
    email:           nextEmail       || '',
    logradouro:      nextLogradouro  || c.logradouro  || '',
    endereco:        nextLogradouro  || c.logradouro  || '',
    bairro:          (nextBairro     || c.bairro      || '').trim(),
    number:          nextNumero      || c.number      || c.numero || '',
    numero:          nextNumero      || c.numero      || c.number || '',
    complemento:     nextComplemento || c.complemento || '',
    pontoReferencia: nextReferencia  || c.pontoReferencia || '',
    cep:             nextCep         || c.cep || '',
  };
  currentState.customer = { ...(currentState.customer || {}), ...patch };
  if (currentState.ticketApi?.customer) currentState.ticketApi.customer = { ...(currentState.ticketApi.customer || {}), ...patch };
  currentState.ticketApiError = '';
  renderCustomer(currentState);
  await syncCustomerToTicket(patch, { cepWasChanged: false });
  return { ok: true };
}

// ─── Render: confirmação de CEP ──────────────────────────────────────────────

function renderCepAvailabilityResult(cep, result) {
  const root = qs('#customerGrid');
  if (!root) return;
  const e   = (v) => escapeHtml(String(v || ''));
  const ok  = !!result?.result;
  const addr = result?.address || {};
  const lines = [
    addr.publicPlace ? `${addr.publicPlace}` : null,
    addr.neighborhood || null,
    addr.locality && addr.state ? `${addr.locality} - ${addr.state}` : (addr.locality || addr.state || null),
    `CEP: ${e(cep)}`,
    addr.ibge ? `IBGE: ${addr.ibge}` : null,
  ].filter(Boolean);

  const msgCode = !ok ? getCepAvailabilityMessage(result?.code) : null;

  // Serializa o endereço para passar no botão via data attribute
  const addrJson = ok ? escapeHtml(JSON.stringify({
    cep:      cep,
    locality: addr.locality  || '',
    state:    addr.state     || '',
    ibge:     addr.ibge      || '',
    neighborhood: addr.neighborhood || '',
    publicPlace:  addr.publicPlace  || '',
  })) : '';

  root.innerHTML = `
  <div class="form-card compact-stack customer-layout-card cep-confirm-card ${ok ? 'cep-ok' : 'cep-fail'}">
    <div class="cep-confirm-header">
      <span class="cep-confirm-icon">${ok ? '✅' : '❌'}</span>
      <div>
        <div class="form-title">${ok ? 'CEP com viabilidade' : 'CEP sem viabilidade'}</div>
        <div class="form-help">${ok ? 'Endereço verificado com sucesso.' : escapeHtml(msgCode)}</div>
      </div>
    </div>
    ${lines.length ? `<div class="cep-confirm-body">${lines.map(l => `<div class="cep-confirm-line">${l}</div>`).join('')}</div>` : ''}
    <div style="display:flex;flex-direction:row;gap:8px;margin-top:4px;">
      ${ok ? `<button id="cepUseBtn" type="button" data-addr="${addrJson}" style="flex:1;border:0;border-radius:10px;background:#0f8a4b;color:#fff;padding:10px 12px;font:inherit;font-size:12px;font-weight:700;cursor:pointer;">Usar este CEP</button>` : ''}
      <button id="cepConfirmBack" type="button" style="flex:1;border:1px solid var(--border);border-radius:10px;background:#fff;color:var(--text);padding:10px 12px;font:inherit;font-size:12px;font-weight:700;cursor:pointer;">← Voltar</button>
    </div>
  </div>`;

  // Attach handlers directly
  const useBtn = qs('#cepUseBtn');
  if (useBtn) {
    useBtn.onclick = () => {
      try {
        const addr = JSON.parse(useBtn.getAttribute('data-addr') || '{}');
        const patch = {
          cep:        normalizePostalCode(addr.cep || ''),
          cidade:     addr.locality     || '',
          city:       addr.locality     || '',
          uf:         addr.state        || '',
          estado:     addr.state        || '',
          ibgeCode:   addr.ibge         || '',
          bairro:     addr.neighborhood || '',
          logradouro: addr.publicPlace  || '',
          endereco:   addr.publicPlace  || '',
          number: '', numero: '', complemento: '', pontoReferencia: '',
        };
        currentState.customer = { ...(currentState.customer || {}), ...patch };
        if (currentState.ticketApi?.customer) currentState.ticketApi.customer = { ...(currentState.ticketApi.customer || {}), ...patch };
        if (currentState.ticketApi) currentState.ticketApi.ibgeCode = patch.ibgeCode;
        availabilityCache.delete(scheduleRequestKey(currentState));
        currentState.scheduleOptionsLoaded = false;
        renderCustomer(currentState);
        const fb = qs('#customerAddressFeedback');
        if (fb) { fb.style.display = 'block'; fb.style.color = 'var(--muted)'; fb.textContent = 'CEP aplicado. Preencha número, complemento e referência e clique em Salvar alteração.'; }
      } catch { renderCustomer(currentState); }
    };
  }

  const backBtn = qs('#cepConfirmBack');
  if (backBtn) {
    backBtn.onclick = () => renderCustomer(currentState);
  }
}

// ─── Render: cliente ──────────────────────────────────────────────────────────

// Feedback toast — reutiliza o mesmo #copyToast do protocolo
let saveToastTimer = null;
function showCustomerToast(msg, type) {
  const toast = qs('#copyToast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.remove('success');
  if (type === 'success') toast.classList.add('success');
  toast.classList.add('show');
  clearTimeout(saveToastTimer);
  saveToastTimer = setTimeout(() => { toast.classList.remove('show', 'success'); }, 4000);
}

function renderCustomer(state) {
  const c = getEffectiveCustomer(state);
  const errHtml = state?.ticketApiError
    ? `<div class="empty warning">${escapeHtml(state.ticketApiError)}</div>` : '';
  qs('#customerGrid').innerHTML = errHtml + renderAddressForm(c);

  // Enable save button only when a field is edited
  const editableInputs = qs('#customerAddressForm')?.querySelectorAll('input[name]') || [];
  editableInputs.forEach(input => {
    input.addEventListener('input', () => {
      const btn = qs('#saveCustomerBtn');
      if (btn) { btn.disabled = false; btn.style.opacity = '1'; btn.style.cursor = 'pointer'; }
    }, { once: false });
  });

  // Attach handlers directly to buttons
  const saveBtn = qs('#saveCustomerBtn');
  if (saveBtn) {
    saveBtn.onclick = async () => {
      saveBtn.disabled = true;
      saveBtn.style.opacity = '.45';
      saveBtn.textContent = 'Salvando...';
      const form = qs('#customerAddressForm');
      const fb   = qs('#customerAddressFeedback');
      if (!form) return;
      if (fb) { fb.style.display = 'block'; fb.style.color = 'var(--muted)'; fb.textContent = 'Salvando...'; }
      try {
        const oldKey = scheduleRequestKey(currentState);
        await updateCustomerAddress(new FormData(form));
        // Success: show toast, re-disable button
        saveBtn.textContent = 'Salvar alteração';
        saveBtn.disabled = true;
        saveBtn.style.opacity = '.45';
        saveBtn.style.cursor = 'default';
        showCustomerToast('✓ Dados salvos com sucesso!', 'success');
        availabilityCache.delete(oldKey);
        availabilityCache.delete(scheduleRequestKey(currentState));
        currentState.scheduleOptionsLoaded = false;
      } catch (err) {
        saveBtn.textContent = 'Salvar alteração';
        saveBtn.disabled = false;
        saveBtn.style.opacity = '1';
        saveBtn.style.cursor = 'pointer';
        showCustomerToast(`Erro ao salvar: ${err?.message || 'tente novamente.'}`);
      }
    };
  }

  const cepBtn = qs('#cepCheckBtn');
  if (cepBtn) {
    cepBtn.onclick = async () => {
      const input  = qs('input[name="cep"]');
      const fb     = qs('#customerAddressFeedback');
      const cepRaw = normalizePostalCode(input?.value || '');
      if (cepRaw.length !== 8) {
        if (fb) { fb.style.display = 'block'; fb.style.color = 'var(--danger)'; fb.textContent = 'Informe um CEP válido com 8 dígitos.'; }
        return;
      }
      cepBtn.disabled = true;
      cepBtn.textContent = 'Consultando...';
      if (fb) { fb.style.display = 'none'; fb.textContent = ''; }
      try {
        const result = await checkCepAvailability(cepRaw);
        renderCepAvailabilityResult(cepRaw, result);
      } catch (err) {
        cepBtn.disabled = false;
        cepBtn.textContent = 'Consultar';
        if (fb) { fb.style.display = 'block'; fb.style.color = 'var(--danger)'; fb.textContent = err?.message || 'Falha ao consultar CEP.'; }
      }
    };
  }
}

function renderAddressForm(c) {
  const e = (v) => escapeHtml(v || '');
  // Email: mostra vazio se for "Não informado" para permitir edição limpa
  const emailVal = (c.email && c.email.toLowerCase() !== 'não informado' && c.email.toLowerCase() !== 'nao informado') ? c.email : '';
  return `
  <form id="customerAddressForm" class="form-card compact-stack customer-layout-card">
    <div class="form-grid distributed customer-form-grid customer-pairs-grid">
      <label class="input-group disabled span-2"><span>Nome</span><input value="${e(c.nome||c.name)}" disabled /></label>
      <label class="input-group disabled"><span>CPF</span><input value="${e(c.cpf||c.document)}" disabled /></label>
      <label class="input-group disabled"><span>Telefone</span><input value="${e(c.telefone||c.phone)}" disabled /></label>
      <label class="input-group editable"><span>Telefone 2</span><input name="telefone2" value="${e(c.phoneOutro2)}" placeholder="Telefone 2" /></label>
      <label class="input-group editable span-2"><span>E-mail</span><input name="email" value="${e(emailVal)}" placeholder="email@exemplo.com" /></label>
      <label class="input-group disabled"><span>Cidade</span><input value="${e(c.cidade||c.city)}" disabled /></label>
      <label class="input-group disabled"><span>UF</span><input value="${e(c.uf||c.estado)}" disabled /></label>
      <div class="input-group editable cep-field-group span-2">
        <span>CEP</span>
        <div style="display:flex;flex-direction:row;gap:5px;align-items:center;">
          <input name="cep" value="${e(c.cep)}" placeholder="00000000" maxlength="9" style="flex:1;min-width:0;width:0;" />
          <button id="cepCheckBtn" type="button" style="flex:0 0 auto;border:1px solid var(--blue);border-radius:8px;background:var(--blue-bg);color:var(--blue);font:inherit;font-size:11px;font-weight:700;padding:0 10px;height:30px;cursor:pointer;white-space:nowrap;">Consultar</button>
        </div>
      </div>
      <label class="input-group editable span-2"><span>Logradouro</span><input name="logradouro" value="${e(c.logradouro||c.endereco)}" placeholder="Logradouro" /></label>
      <label class="input-group editable"><span>Bairro</span><input name="bairro" value="${e(c.bairro)}" /></label>
      <label class="input-group editable"><span>Número</span><input name="numero" value="${e(c.number||c.numero)}" placeholder="Nº" /></label>
      <label class="input-group editable span-2"><span>Complemento</span><input name="complemento" value="${e(c.complemento)}" /></label>
      <label class="input-group editable span-2"><span>Referência</span><input name="pontoReferencia" value="${e(c.pontoReferencia)}" /></label>
    </div>
    <button id="saveCustomerBtn" type="button" class="primary-btn" disabled style="opacity:.45;cursor:default;">Salvar alteração</button>
    <div id="customerAddressFeedback" class="mini-feedback" style="display:none;"></div>
  </form>`;
}

// ─── Render: agendamento ──────────────────────────────────────────────────────

function renderSchedule(state) {
  const root = qs('#scheduleGrid');
  if (!root) return;
  const options      = Array.isArray(state?.scheduleOptions) ? state.scheduleOptions : [];
  const selectedDate = state?.selectedScheduleDate || '';

  let body = state?.scheduleSuccess ? `<div class="empty success">${escapeHtml(state.scheduleSuccess)}</div>` : '';

  if (state?.scheduleLoading) {
    body += '<div class="empty">Buscando datas disponíveis...</div>';
  } else if (state?.scheduleError) {
    body += `<div class="empty warning">${escapeHtml(state.scheduleError)}</div>
      <div class="form-card compact-stack">
        <button id="startScheduleBtn" class="primary-btn" type="button">Tentar novamente</button>
      </div>`;
  } else if (!state?.scheduleOptionsLoaded) {
    body += `<div class="form-card compact-stack">
      <div class="form-title">Agendamento</div>
      <div class="form-help">Clique no botão abaixo para consultar as datas disponíveis.</div>
      <button id="startScheduleBtn" class="primary-btn" type="button">Iniciar agendamento</button>
      <div id="scheduleFeedback" class="mini-feedback"></div>
    </div>`;
  } else if (!options.length) {
    body += `<div class="form-card compact-stack">
      <div class="form-title">Agendamento</div>
      <div class="form-help">Nenhuma data disponível encontrada.</div>
      <button id="startScheduleBtn" class="primary-btn" type="button">Buscar novamente</button>
    </div>`;
  } else {
    body += `<form id="scheduleForm" class="form-card compact-stack">
      <div class="form-title">Escolha uma data</div>
      <div class="schedule-options">${options.map((o, i) => `
        <label class="schedule-option${selectedDate === o.date || (!selectedDate && i === 0) ? ' selected' : ''}">
          <input type="radio" name="scheduleDate" value="${escapeHtml(o.date||'')}"
            ${selectedDate === o.date || (!selectedDate && i === 0) ? 'checked' : ''} />
          <span>${escapeHtml(formatScheduleDate(o.date||''))}</span>
        </label>`).join('')}</div>
      <button class="primary-btn" type="submit">Agendar</button>
      <div id="scheduleFeedback" class="mini-feedback">${selectedDate ? `Data selecionada: ${escapeHtml(formatScheduleDate(selectedDate))}` : ''}</div>
    </form>`;
  }
  root.innerHTML = body;
}

// ─── Render: anexos ───────────────────────────────────────────────────────────

function renderAttachments(state) {
  const items = Array.isArray(state?.attachments) ? state.attachments : [];
  const gallery = items.filter((i) => (i.url||i.href) && isImageAttachment(i.nome||i.name||'', i.tipo||i.type||'')).map((i) => ({ src: i.url||i.href||'', name: i.nome||i.name||'Arquivo' }));
  qs('#attachmentsList').innerHTML = items.length ? items.map((item, idx) => {
    const name = item.nome||item.name||'Arquivo', href = item.url||item.href||'';
    const meta = [item.titulo||'', item.tipo||item.type||'', formatBytes(item.tamanho)].filter(Boolean).join(' • ');
    const canPrev = href && isImageAttachment(name, item.tipo||item.type||'');
    const gIdx = canPrev ? gallery.findIndex((g) => g.src === href) : -1;
    const thumb = canPrev ? `<div class="attachment-thumb-wrap" data-preview-src="${escapeHtml(href)}" data-preview-name="${escapeHtml(name)}" data-preview-index="${gIdx}" title="Clique para ampliar"><img class="attachment-thumb" src="${escapeHtml(href)}" alt="${escapeHtml(name)}" loading="lazy" /></div>` : '';
    const replaceBtn = `<button class="btn-replace-attachment" data-attachment-index="${idx}" title="Substituir imagem"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>`;
    return `<div class="card attachment-card">${thumb}<div class="card-title">${escapeHtml(name)}</div><div class="card-sub">${escapeHtml(meta||'Arquivo disponível')}</div>${replaceBtn}</div>`;
  }).join('') : '<div class="empty">Nenhum arquivo encontrado para este protocolo.</div>';
}

// ─── Modal de substituição de anexo ──────────────────────────────────────────
let replaceModalAttachment = null;
let replaceModalFile       = null;

function openReplaceModal(attachment) {
  replaceModalAttachment = attachment;
  replaceModalFile = null;
  const modal   = qs('#replaceModal');
  const nameEl  = qs('#replaceModalName');
  const preview = qs('#replacePreviewImg');
  const previewName = qs('#replacePreviewName');
  const dzInner = qs('#replaceDropzoneInner');
  const feedback = qs('#replaceModalFeedback');
  const confirmBtn = qs('#replaceModalConfirm');
  if (nameEl) nameEl.textContent = attachment.titulo || attachment.nome || '';
  if (preview) { preview.src = ''; preview.classList.add('hidden'); }
  if (previewName) { previewName.textContent = ''; previewName.classList.add('hidden'); }
  if (dzInner) dzInner.style.display = '';
  if (feedback) { feedback.textContent = ''; feedback.className = 'replace-feedback hidden'; }
  if (confirmBtn) confirmBtn.disabled = true;
  if (modal) { modal.classList.remove('hidden'); modal.removeAttribute('aria-hidden'); }
}

function closeReplaceModal() {
  replaceModalAttachment = null;
  replaceModalFile = null;
  const modal = qs('#replaceModal');
  if (modal) { modal.classList.add('hidden'); modal.setAttribute('aria-hidden', 'true'); }
}

function setReplacePreview(file) {
  replaceModalFile = file;
  const preview = qs('#replacePreviewImg');
  const previewName = qs('#replacePreviewName');
  const dzInner = qs('#replaceDropzoneInner');
  const confirmBtn = qs('#replaceModalConfirm');
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (e) => {
    if (preview) { preview.src = e.target.result; preview.classList.remove('hidden'); }
    if (dzInner) dzInner.style.display = 'none';
  };
  reader.readAsDataURL(file);
  if (previewName) { previewName.textContent = `${file.name} (${formatBytes(file.size)})`; previewName.classList.remove('hidden'); }
  if (confirmBtn) confirmBtn.disabled = false;
}

async function doReplaceAttachment() {
  if (!replaceModalAttachment || !replaceModalFile) return;
  const confirmBtn = qs('#replaceModalConfirm');
  const cancelBtn  = qs('#replaceModalCancel');
  const feedback   = qs('#replaceModalFeedback');
  const setFb = (msg, type) => {
    if (!feedback) return;
    feedback.textContent = msg;
    feedback.className = `replace-feedback ${type}`;
  };
  if (confirmBtn) { confirmBtn.disabled = true; confirmBtn.textContent = 'Enviando...'; }
  if (cancelBtn)  cancelBtn.disabled = true;
  try {
    const attachment = replaceModalAttachment;

    // FormData direto para /replace (multipart)
    const fd = new FormData();
    fd.append('file',     replaceModalFile, replaceModalFile.name);
    fd.append('protocol', attachment.protocol);
    if (attachment.key)          fd.append('key',          attachment.key);
    if (attachment.ticketId)     fd.append('ticketId',     attachment.ticketId);
    if (attachment.attachmentId) fd.append('attachmentId', attachment.attachmentId);
    if (attachment.titulo || attachment.nome) fd.append('name', attachment.titulo || attachment.nome);

    const r = await fetch(`${EAF_BASE_URL}/replace`, { method: 'PUT', body: fd });
    if (!r.ok) {
      let msg = `Erro ${r.status}`;
      try {
        const e = await r.json();
        const base = e?.message || e?.error || msg;
        // Inclui detalhes do CRM se disponível
        const detail = e?.details ? ` — CRM: ${JSON.stringify(e.details)}` : '';
        const crmStatus = e?.crm_status ? ` (CRM HTTP ${e.crm_status})` : '';
        msg = `${base}${crmStatus}${detail}`;
      } catch {}
      throw new Error(msg);
    }

    // 3. Invalida cache e recarrega
    const cacheKey = `${attachment.protocol}_${attachment.ticketId || ''}`;
    attachmentCache.delete(cacheKey);
    if (currentState) currentState.attachments = [];

    setFb('✅ Imagem substituída com sucesso!', 'success');
    setTimeout(() => {
      closeReplaceModal();
      ensureAttachmentsLoaded(currentState, { force: true }).catch(() => {});
    }, 1200);
  } catch (err) {
    setFb(`Erro: ${err?.message || err}`, 'error');
    if (confirmBtn) { confirmBtn.disabled = false; confirmBtn.textContent = 'Substituir'; }
    if (cancelBtn)  cancelBtn.disabled = false;
  }
}

// Setup dos eventos do modal de substituição
(function setupReplaceModal() {
  // Abrir modal ao clicar no botão de substituir
  document.addEventListener('click', (event) => {
    const btn = event.target.closest('.btn-replace-attachment');
    if (!btn) return;
    const idx = Number(btn.dataset.attachmentIndex);
    const item = (currentState?.attachments || [])[idx];
    if (item) openReplaceModal(item);
  });

  // Fechar modal
  document.addEventListener('click', (event) => {
    if (event.target.closest('[data-close-replace-modal]') || event.target.id === 'replaceModalClose' || event.target.id === 'replaceModalCancel')
      closeReplaceModal();
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeReplaceModal(); });

  // Dropzone: clique
  const dz = qs('#replaceDropzone');
  const fileInput = qs('#replaceFileInput');
  if (dz) dz.addEventListener('click', () => fileInput?.click());
  if (fileInput) fileInput.addEventListener('change', () => { if (fileInput.files?.[0]) setReplacePreview(fileInput.files[0]); });

  // Dropzone: drag & drop
  if (dz) {
    dz.addEventListener('dragover', (e) => { e.preventDefault(); dz.classList.add('drag-over'); });
    dz.addEventListener('dragleave', () => dz.classList.remove('drag-over'));
    dz.addEventListener('drop', (e) => {
      e.preventDefault(); dz.classList.remove('drag-over');
      const file = e.dataTransfer?.files?.[0];
      if (file && file.type.startsWith('image/')) setReplacePreview(file);
    });
  }

  // Confirmar substituição
  const confirmBtn = qs('#replaceModalConfirm');
  if (confirmBtn) confirmBtn.addEventListener('click', doReplaceAttachment);
})();

// ─── Render: validador ────────────────────────────────────────────────────────

let validatorLoadTimer = null;
function showValidatorLoader(show) {
  const el = qs('#validatorLoader');
  if (el) el.classList.toggle('hidden', !show);
}
function armValidatorLoaderTimeout() {
  clearTimeout(validatorLoadTimer);
  validatorLoadTimer = setTimeout(() => showValidatorLoader(false), 15000);
}
function buildValidatorUrl(state) {
  // CPF do cliente (prioriza API de ticket, fallback DOM)
  const c   = getEffectiveCustomer(state);
  const cpf = normalizeDigits(c.document || c.cpf || '');
  // Email do operador: vem do contexto emitido pelo hook.js (lido do localStorage do Desk)
  const email = String(state?.agentEmail || '').trim();
  if (!cpf) return ''; // sem CPF não abre validador

  const url = new URL(VALIDATOR_BASE_URL);
  url.searchParams.set('token',          VALIDATOR_TOKEN);
  url.searchParams.set('id_crm',         VALIDATOR_ID_CRM);
  url.searchParams.set('grupo',          VALIDATOR_GRUPO);
  url.searchParams.set('cpf',            cpf);
  if (email) url.searchParams.set('email_operador', email);
  return url.toString();
}

function renderValidator(state) {
  const frame = qs('#validatorFrame'), empty = qs('#validatorEmpty'), shell = qs('#validatorShell');
  const url = buildValidatorUrl(state);

  if (!url) {
    // Sem CPF ainda — mostra mensagem de espera
    if (empty) { empty.style.display = 'block'; empty.textContent = 'Aguardando CPF do cliente para carregar o validador.'; }
    if (shell) shell.style.display = 'none';
    if (frame) { frame.style.display = 'none'; frame.removeAttribute('src'); }
    const cdb = qs('#customerDataBtn'); if (cdb) cdb.style.display = 'none';
    showValidatorLoader(false); clearTimeout(validatorLoadTimer); return;
  }
  if (empty) empty.style.display = 'none';
  if (shell) shell.style.display = 'block';
  if (frame && frame.src !== url) {
    showValidatorLoader(true); armValidatorLoaderTimeout(); frame.src = url;
  }
  if (frame) frame.style.display = 'block';
}

// ─── Render principal ─────────────────────────────────────────────────────────

function buildContextKey(state) {
  const c = state?.customer || {};
  return [
    normalizeProtocol(state?.protocol || state?.ticketDisplay || ''),
    normalizeProtocol(state?.ticketId || ''),
    normalizeDigits(c.document || c.cpf || ''),
    normalizeDigits(c.phone || c.telefone || ''),
    coalesce(c.name, c.nome),
  ].join('|');
}

function render(state, isDeskTab = true) {
  const nextKey  = buildContextKey(state || {});
  const prevKey  = buildContextKey(currentState || {});
  const tabChanged     = !!(state?.tabId && currentState?.tabId && state.tabId !== currentState.tabId)
                      || !!(state?.ticketId && currentState?.ticketId && state.ticketId !== currentState.ticketId);
  const contextChanged = !!nextKey && !!prevKey && nextKey !== prevKey;
  const shouldReset    = tabChanged || contextChanged;

  currentState = {
    ...(state || {}),
    customer:             shouldReset ? (state?.customer || {}) : { ...(currentState?.customer || {}), ...(state?.customer || {}) },
    ticketApi:            shouldReset ? null : (state?.ticketApi || currentState?.ticketApi || null),
    attachments:          shouldReset ? (state?.attachments || []) : (state?.attachments || currentState?.attachments || []),
    scheduleOptions:      shouldReset ? [] : (state?.scheduleOptions || currentState?.scheduleOptions || []),
    selectedScheduleDate: shouldReset ? '' : (state?.selectedScheduleDate || currentState?.selectedScheduleDate || ''),
    scheduleLoading:      shouldReset ? false : (state?.scheduleLoading ?? currentState?.scheduleLoading ?? false),
    scheduleOptionsLoaded:shouldReset ? false : (state?.scheduleOptionsLoaded || currentState?.scheduleOptionsLoaded || false),
    scheduleError:        '',
    ticketApiError:       '',
    contextKey:           nextKey,
    // agentEmail: preserva sempre o último valor recebido do hook
    agentEmail: state?.agentEmail || currentState?.agentEmail || '',
  };

  // Protocolo exibido: sempre do profileInfo (DOM)
  const protocolEl = qs('#protocolValue');
  if (protocolEl) protocolEl.textContent = currentState?.protocol || currentState?.ticketDisplay || '···';

  if (!isDeskTab) {
    setStatus('Este painel só funciona nas páginas do Blip Desk.', 'muted');
    renderValidator(null); renderCustomer(null); renderAttachments(null); renderSchedule(null);
    return;
  }

  // On ticket change: clear customer grid immediately so stale data is not shown
  if (shouldReset && activeTab === 'cliente') {
    const g = qs('#customerGrid');
    if (g) g.innerHTML = '<div class="empty">Carregando dados do cliente...</div>';
  }
  if (!currentState?.ticketId)   setStatus('Selecione um ticket no Blip Desk para carregar os dados.', 'muted');
  else if (currentState?.error)  setStatus(currentState.error, 'error');
  else if (currentState?.loading)setStatus('Carregando dados do ticket…', 'muted');
  else                           setStatus('');

  renderValidator(currentState);
  // Only render the active tab — avoids destroying onclick handlers on re-render
  if (activeTab === 'cliente')     renderCustomer(currentState);
  if (activeTab === 'anexo')       renderAttachments(currentState);
  if (activeTab === 'agendamento') renderSchedule(currentState);

  if (activeTab === 'anexo' && isDeskTab) ensureAttachmentsLoaded(currentState).catch(() => {});
  if (currentState?.ticketId)            ensureTicketDataLoaded(currentState).catch(() => {});
}

function setStatus(text, kind = 'muted') {
  const box = qs('#statusBox');
  if (!box) return;
  if (!text) { box.className = 'status hidden'; box.textContent = ''; return; }
  box.className = `status ${kind}`; box.textContent = text;
}

// ─── Modal de imagem ──────────────────────────────────────────────────────────

function getModalEls() {
  return { modal: qs('#imageModal'), image: qs('#imageModalImg'), caption: qs('#imageModalCaption'), prev: qs('#imageModalPrev'), next: qs('#imageModalNext'), wrap: qs('.modal-image-wrap') };
}
function resetModalZoom() {
  const { image, wrap } = getModalEls();
  modalZoom = 1; modalDragState = null;
  if (image) { image.style.transform = 'scale(1)'; image.classList.remove('is-zoomed','is-dragging'); }
  if (wrap)  { wrap.scrollTop = 0; wrap.scrollLeft = 0; }
}
function renderModalImage() {
  const { modal, image, caption, prev, next } = getModalEls();
  const item = modalGalleryItems[modalGalleryIndex];
  if (!modal || !image || !caption || !item) return;
  image.src = item.src; image.alt = item.name || 'Anexo';
  const count = modalGalleryItems.length > 1 ? ` <span class="modal-counter">${modalGalleryIndex+1}/${modalGalleryItems.length}</span>` : '';
  caption.innerHTML = `${escapeHtml(item.name||'')}${count}`;
  if (prev) prev.classList.toggle('hidden', modalGalleryItems.length < 2);
  if (next) next.classList.toggle('hidden', modalGalleryItems.length < 2);
  resetModalZoom();
}
function openImageModal(src, caption='', items=[], startIndex=0) {
  const { modal } = getModalEls();
  if (!modal || !src) return;
  modalGalleryItems = Array.isArray(items) && items.length ? items : [{ src, name: caption||'Anexo' }];
  modalGalleryIndex = Math.max(0, modalGalleryItems.findIndex((i) => i.src === src));
  if (modalGalleryIndex < 0) modalGalleryIndex = Math.max(0, startIndex||0);
  renderModalImage();
  modal.classList.remove('hidden'); modal.setAttribute('aria-hidden','false');
  document.body.classList.add('modal-open');
}
function closeImageModal() {
  const { modal, image, caption } = getModalEls();
  if (!modal||!image||!caption) return;
  modal.classList.add('hidden'); modal.setAttribute('aria-hidden','true');
  image.removeAttribute('src'); caption.textContent = '';
  modalGalleryItems = []; modalGalleryIndex = -1;
  resetModalZoom(); document.body.classList.remove('modal-open');
}
function changeModalImage(step) {
  if (modalGalleryItems.length < 2) return;
  modalGalleryIndex = (modalGalleryIndex + step + modalGalleryItems.length) % modalGalleryItems.length;
  renderModalImage();
}
function setModalZoom(next) {
  const { image } = getModalEls();
  if (!image) return;
  modalZoom = Math.min(4, Math.max(1, next));
  image.style.transform = `scale(${modalZoom})`;
  image.classList.toggle('is-zoomed', modalZoom > 1);
}

// ─── Preview inline (abre no page) ───────────────────────────────────────────

async function openAttachmentPreviewInPage(items, startIndex) {
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs?.[0];
    if (!tab?.id) return false;
    await chrome.tabs.sendMessage(tab.id, { type: 'OPEN_ATTACHMENT_PREVIEW', items, startIndex: Math.max(0, Number(startIndex)||0) });
    return true;
  } catch { return false; }
}

// ─── Navegação (tabs) ─────────────────────────────────────────────────────────

function resetScheduleState() {
  if (!currentState) return;
  currentState.selectedScheduleDate = '';
  currentState.scheduleOptions = [];
  currentState.scheduleOptionsLoaded = false;
  currentState.scheduleLoading = false;
  currentState.scheduleError = '';
  currentState.scheduleSuccess = '';
}

function switchTab(tab) {
  if (activeTab === 'agendamento' && tab !== 'agendamento') resetScheduleState();
  activeTab = tab;
  document.querySelectorAll('.tab').forEach((el) => el.classList.toggle('active', el.dataset.tab === tab));
  document.querySelectorAll('.tab-panel').forEach((el) => el.classList.toggle('active', el.id === `tab-${tab}`));
  if (tab === 'anexo')       ensureAttachmentsLoaded(currentState, { force: true }).catch(() => {});
  if (tab === 'cliente') {
    renderCustomer(currentState);
    ensureTicketDataLoaded(currentState, { force: false }).catch(() => {});
  }
  if (tab === 'agendamento') {
    ensureTicketDataLoaded(currentState, { force: false }).catch(() => {});
    renderSchedule(currentState);
  }
}

// ─── Carregamento do estado da aba ───────────────────────────────────────────

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs?.[0] || null;
}

async function loadStateForActiveTab() {
  const tab = await getActiveTab();
  currentTabId = tab?.id || null;
  if (!currentTabId || !DESK_URL_RE.test(String(tab?.url || ''))) {
    render(null, false); return;
  }
  const response = await chrome.runtime.sendMessage({ type: 'GET_TAB_CONTEXT', tabId: currentTabId });
  render(response?.payload || null, true);
}

// ─── Listeners ────────────────────────────────────────────────────────────────

// Tabs
document.querySelectorAll('.tab').forEach((btn) => btn.addEventListener('click', () => switchTab(btn.dataset.tab)));

// Copiar protocolo
let copyFeedbackTimer = null;
qs('#copyProtocolBtn').addEventListener('click', async () => {
  const value = currentState?.protocol || currentState?.ticketDisplay || '';
  if (!value) return;
  const toast = qs('#copyToast');
  let copied = false;
  try { await navigator.clipboard.writeText(value); copied = true; } catch {}
  if (toast) {
    toast.textContent = copied ? 'Protocolo copiado' : 'Falha ao copiar';
    toast.classList.add('show');
    clearTimeout(copyFeedbackTimer);
    copyFeedbackTimer = setTimeout(() => toast.classList.remove('show'), 1400);
  }
});

// Refresh
qs('#refreshBtn').addEventListener('click', async () => {
  const tab = await getActiveTab();
  currentTabId = tab?.id || null;
  if (!currentTabId || !DESK_URL_RE.test(String(tab?.url || ''))) { render(null, false); return; }
  if (currentState) {
    const doc = getCurrentDocument(currentState);
    const cacheKey = `${currentState?.ticketId || ''}_${doc}`;
    if (doc) { ticketCache.delete(cacheKey); ticketCache.delete(doc); }
    availabilityCache.delete(scheduleRequestKey(currentState));
    currentState.scheduleOptionsLoaded = false;
  }
  try { await chrome.runtime.sendMessage({ type: 'REFRESH_TAB_CONTEXT', tabId: currentTabId, forceReload: true, reason: 'sidepanel-refresh' }); } catch {}
  setTimeout(() => loadStateForActiveTab().catch(() => {}), 250);
});

// Cliques delegados (botões dinâmicos)
document.addEventListener('click', async (event) => {
  // Salvar dados do cliente
  if (event.target?.id === 'saveCustomerBtn') {
    event.preventDefault();
    const form = qs('#customerAddressForm');
    const fb   = qs('#customerAddressFeedback');
    if (!form) { alert('Formulário não encontrado'); return; }
    if (fb) { fb.textContent = 'Salvando...'; fb.style.display = 'block'; fb.style.color = 'var(--muted)'; }
    try {
      const oldScheduleKey = scheduleRequestKey(currentState);
      await updateCustomerAddress(new FormData(form));
      if (fb) { fb.textContent = 'Dados salvos com sucesso.'; fb.style.color = '#0f8a4b'; }
      availabilityCache.delete(oldScheduleKey);
      availabilityCache.delete(scheduleRequestKey(currentState));
      currentState.scheduleOptionsLoaded = false;
    } catch (err) {
      if (fb) { fb.textContent = `Erro: ${err?.message || 'Falha ao salvar.'}`; fb.style.color = 'var(--danger)'; }
    }
    return;
  }

  // Botão "Consultar CEP" — verifica viabilidade via CRM, só exibe resultado
  if (event.target?.id === 'cepCheckBtn') {
    event.preventDefault();
    const input = qs('input[name="cep"]');
    if (!input) return;
    const cepRaw = normalizePostalCode(input.value);
    if (cepRaw.length !== 8) {
      const fb = qs('#customerAddressFeedback');
      if (fb) fb.textContent = 'Informe um CEP válido com 8 dígitos.';
      return;
    }
    const btn = event.target;
    btn.disabled = true;
    btn.textContent = 'Consultando...';
    const fb = qs('#customerAddressFeedback');
    if (fb) fb.textContent = '';
    try {
      const result = await checkCepAvailability(cepRaw);
      renderCepAvailabilityResult(cepRaw, result);
    } catch (err) {
      btn.disabled = false;
      btn.textContent = 'Consultar';
      if (fb) fb.textContent = err?.message || 'Falha ao consultar CEP.';
    }
    return;
  }

  // "Usar este CEP" — aplica o endereço no estado e volta ao formulário
  if (event.target?.id === 'cepUseBtn') {
    event.preventDefault();
    try {
      const addrRaw = event.target.getAttribute('data-addr') || '{}';
      const addr = JSON.parse(addrRaw);
      // Ao usar novo CEP: limpa todos os campos de endereço antigos antes de aplicar
      const patch = {
        cep:        normalizePostalCode(addr.cep || ''),
        cidade:     addr.locality      || '',
        city:       addr.locality      || '',
        uf:         addr.state         || '',
        estado:     addr.state         || '',
        ibgeCode:   addr.ibge          || '',
        // Campos que vêm da API de viabilidade (podem ser vazios — limpa os antigos)
        bairro:     addr.neighborhood  || '',
        logradouro: addr.publicPlace   || '',
        endereco:   addr.publicPlace   || '',
        // Campos dependentes do endereço: zera para o usuário preencher
        number:     '',
        numero:     '',
        complemento: '',
        pontoReferencia: '',
      };
      currentState.customer = { ...(currentState.customer || {}), ...patch };
      if (currentState.ticketApi?.customer) currentState.ticketApi.customer = { ...(currentState.ticketApi.customer || {}), ...patch };
      if (currentState.ticketApi) currentState.ticketApi.ibgeCode = patch.ibgeCode;
      availabilityCache.delete(scheduleRequestKey(currentState));
      currentState.scheduleOptionsLoaded = false;
      renderCustomer(currentState);
      const fb = qs('#customerAddressFeedback');
      if (fb) fb.textContent = 'CEP aplicado. Preencha número, complemento e referência e clique em Salvar alteração.';
    } catch (err) {
      renderCustomer(currentState);
    }
    return;
  }

  // Voltar ao formulário após ver resultado de viabilidade
  if (event.target?.id === 'cepConfirmBack') {
    event.preventDefault();
    renderCustomer(currentState);
    return;
  }

  if (event.target?.id === 'startScheduleBtn') {
    event.preventDefault();
    if (!currentState) return;
    currentState.scheduleSuccess = '';
    currentState.scheduleError = '';
    currentState.scheduleLoading = true;
    renderSchedule(currentState);
    await ensureTicketDataLoaded(currentState, { force: false });
    await ensureAvailabilitiesLoaded(currentState, { force: true });
    return;
  }

});

// Submits delegados
document.addEventListener('submit', async (event) => {
  // customerAddressForm agora usa click em #saveCustomerBtn (não submit)
  if (event.target?.id === 'scheduleForm') {
    event.preventDefault();
    const sel = event.target.querySelector('input[name="scheduleDate"]:checked');
    currentState.selectedScheduleDate = sel?.value || currentState.selectedScheduleDate || '';
    const fb = qs('#scheduleFeedback');
    if (fb) fb.textContent = 'Enviando...';
    try {
      await submitSelectedSchedule();
    } catch (err) {
      if (fb) fb.textContent = '';
      showCustomerToast(err?.message || 'Falha ao enviar agendamento.');
    }
  }
});

// Mudança de data no agendamento
document.addEventListener('change', (event) => {
  if (event.target?.matches?.('input[name="scheduleDate"]')) {
    currentState.selectedScheduleDate = event.target.value || '';
    const fb = qs('#scheduleFeedback');
    if (fb) fb.textContent = currentState.selectedScheduleDate ? `Data selecionada: ${formatScheduleDate(currentState.selectedScheduleDate)}` : '';
  }
});

// Anexos: preview
const attachmentsList = qs('#attachmentsList');
if (attachmentsList) {
  attachmentsList.addEventListener('click', async (event) => {
    const trigger = event.target.closest('[data-preview-src]');
    if (!trigger) return;
    const items = (currentState?.attachments||[]).filter((i) => isImageAttachment(i.nome||i.name||'', i.tipo||i.type||'') && (i.url||i.href)).map((i) => ({ src: i.url||i.href||'', name: i.nome||i.name||'Arquivo' }));
    const opened = await openAttachmentPreviewInPage(items, Number(trigger.dataset.previewIndex||0));
    if (!opened) openImageModal(trigger.dataset.previewSrc||'', trigger.dataset.previewName||'', items, Number(trigger.dataset.previewIndex||0));
  });
}

// Modal
const imageModal = qs('#imageModal');
if (imageModal) imageModal.addEventListener('click', (e) => { if (e.target.closest('[data-close-modal="true"]') || e.target.id === 'imageModalClose') closeImageModal(); });
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeImageModal();
  else if (e.key === 'ArrowLeft'  && !qs('#imageModal')?.classList.contains('hidden')) changeModalImage(-1);
  else if (e.key === 'ArrowRight' && !qs('#imageModal')?.classList.contains('hidden')) changeModalImage(1);
  else if ((e.key === '+' || e.key === '=') && !qs('#imageModal')?.classList.contains('hidden')) setModalZoom(modalZoom + 0.2);
  else if (e.key === '-' && !qs('#imageModal')?.classList.contains('hidden')) setModalZoom(modalZoom - 0.2);
});
const modalPrevBtn = qs('#imageModalPrev');
if (modalPrevBtn) modalPrevBtn.addEventListener('click', (e) => { e.stopPropagation(); changeModalImage(-1); });
const modalNextBtn = qs('#imageModalNext');
if (modalNextBtn) modalNextBtn.addEventListener('click', (e) => { e.stopPropagation(); changeModalImage(1); });
const modalImage = qs('#imageModalImg'), modalWrap = qs('.modal-image-wrap');
if (modalImage && modalWrap) {
  modalImage.addEventListener('click', (e) => { e.stopPropagation(); setModalZoom(modalZoom > 1 ? 1 : 2); });
  modalWrap.addEventListener('wheel', (e) => {
    if (qs('#imageModal')?.classList.contains('hidden')) return;
    e.preventDefault(); setModalZoom(modalZoom + (e.deltaY < 0 ? 0.2 : -0.2));
  }, { passive: false });
  modalImage.addEventListener('mousedown', (e) => {
    if (modalZoom <= 1) return;
    modalDragState = { x: e.clientX, y: e.clientY, left: modalWrap.scrollLeft, top: modalWrap.scrollTop };
    modalImage.classList.add('is-dragging'); e.preventDefault();
  });
  window.addEventListener('mousemove', (e) => {
    if (!modalDragState || modalZoom <= 1) return;
    modalWrap.scrollLeft = modalDragState.left - (e.clientX - modalDragState.x);
    modalWrap.scrollTop  = modalDragState.top  - (e.clientY - modalDragState.y);
  });
  window.addEventListener('mouseup', () => { modalDragState = null; modalImage.classList.remove('is-dragging'); });
}
const validatorFrame = qs('#validatorFrame');
if (validatorFrame) {
  validatorFrame.addEventListener('load',  () => { clearTimeout(validatorLoadTimer); showValidatorLoader(false); if (customerDataBtn) customerDataBtn.style.display = ''; });
  validatorFrame.addEventListener('error', () => { clearTimeout(validatorLoadTimer); showValidatorLoader(false); if (customerDataBtn) customerDataBtn.style.display = 'none'; });
}

// Broadcast do contexto (nova mensagem do background)
// ─── Dados do cliente — abre overlay na página do Desk (como as imagens) ─────

async function openCustomerDataInPage() {
  const c = getEffectiveCustomer(currentState);
  const rows = [
    ['Nome',        c.nome || c.name],
    ['CPF',         c.cpf  || c.document],
    ['Telefone',    c.telefone || c.phone],
    ['Telefone 2',  c.phoneOutro2],
    ['E-mail',      c.email],
    ['CEP',         c.cep],
    ['Logradouro',  c.logradouro || c.endereco],
    ['Número',      c.number || c.numero],
    ['Bairro',      c.bairro],
    ['Complemento', c.complemento],
    ['Cidade',      c.cidade || c.city],
    ['UF',          c.uf || c.estado],
    ['Referência',  c.pontoReferencia],
  ];
  try {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const tab = tabs?.[0];
    if (!tab?.id) return;
    await chrome.tabs.sendMessage(tab.id, { type: 'OPEN_CUSTOMER_DATA', rows });
  } catch (err) {
    showCustomerToast('Não foi possível abrir os dados.');
  }
}

const customerDataBtn = qs('#customerDataBtn');
if (customerDataBtn) customerDataBtn.addEventListener('click', openCustomerDataInPage);

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || msg.type !== 'DESK_CONTEXT_BROADCAST') return;
  if (!currentTabId || msg.payload?.tabId !== currentTabId) return;
  render(msg.payload || null, true);
});
chrome.tabs.onActivated.addListener(() => loadStateForActiveTab().catch(() => {}));
chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (tabId === currentTabId && (changeInfo.status === 'complete' || changeInfo.url))
    loadStateForActiveTab().catch(() => {});
});

// ─── Boot ─────────────────────────────────────────────────────────────────────

switchTab(activeTab);
loadStateForActiveTab().catch(() => setStatus('Não foi possível carregar o painel lateral.', 'error'));
